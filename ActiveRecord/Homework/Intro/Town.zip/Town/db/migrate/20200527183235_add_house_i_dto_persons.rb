class AddHouseIDtoPersons < ActiveRecord::Migration[6.0]
  def change
    add_column :persons, :house_id, :integer, null: false
  end
end
