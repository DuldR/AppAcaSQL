class CreatePersons < ActiveRecord::Migration[6.0]
  def change
    create_table :persons do |t|
      t.string :name, Null: false
      t.integer :house_id, Null: false
    end
  end
end
